import React, { useState } from "react";
import "./Login.css";

export default function AdminLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSignIn = () => {
    alert(`Admin login with email: ${email}`);
  };

  return (
    <div className="login-container">
      <div className="logo">
        <div className="shield">🛡️</div>
        <h2>MedTrack</h2>
        <p className="tagline">Your health, always on schedule.</p>
      </div>

      <h3 className="role-title">Admin Login</h3>

      <form className="login-form" onSubmit={(e) => e.preventDefault()}>
        <label>EMAIL</label>
        <input
          type="email"
          placeholder="Enter admin email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <label>PASSWORD</label>
        <input
          type="password"
          placeholder="Enter admin password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <div className="forgot" onClick={() => alert("Admin password recovery")}>
          Forgot password?
        </div>

        <button className="signin-btn" onClick={handleSignIn}>
          Sign In
        </button>

        <div className="biometric" onClick={() => alert("Admin biometric login")}>
          <span role="img" aria-label="fingerprint">🔑</span> Use Biometric / PIN
        </div>
      </form>

      <div className="footer">
        <p>
          Need access?{" "}
          <span className="create" onClick={() => alert("Admin account request")}>
            Request account
          </span>
        </p>
        <small>HIPAA-compliant · End-to-end encrypted</small>
      </div>
    </div>
  );
}
