import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

export default function SubscriptionUpgrade() {
  const [selectedPlan, setSelectedPlan] = useState("annual");

  const handleSubscribe = () => {
    alert(`Subscribed to ${selectedPlan} plan`);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <Text style={styles.header}>MedTrack Pro</Text>
      <Text style={styles.subHeader}>
        Everything you need to manage your health, beautifully.
      </Text>

      {/* Plans */}
      <View style={styles.planContainer}>
        <TouchableOpacity
          style={[
            styles.plan,
            selectedPlan === "monthly" && styles.activePlan,
          ]}
          onPress={() => setSelectedPlan("monthly")}
        >
          <Text style={styles.planTitle}>Monthly</Text>
          <Text style={styles.planPrice}>R89.99 per month</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.plan,
            selectedPlan === "annual" && styles.activePlan,
          ]}
          onPress={() => setSelectedPlan("annual")}
        >
          <Text style={styles.planTitle}>Annual</Text>
          <Text style={styles.save}>Save 33%</Text>
          <Text style={styles.planPrice}>R899.99 per year</Text>
        </TouchableOpacity>
      </View>

      {/* Features */}
      <View style={styles.features}>
        <Text style={styles.feature}>✓ Unlimited medications</Text>
        <Text style={styles.feature}>✓ Cloud backup & sync</Text>
        <Text style={styles.feature}>✓ Adherence analytics & trends</Text>
        <Text style={styles.feature}>✓ PDF export for doctor visits</Text>
        <Text style={styles.feature}>✓ Family member sharing</Text>
        <Text style={styles.feature}>✓ Priority support</Text>
      </View>

      {/* Footer */}
      <Text style={styles.footer}>HIPAA-safe • Cancel anytime</Text>
      <Text style={styles.footer}>Stripe / PayPal</Text>

      {/* Subscribe Button */}
      <TouchableOpacity style={styles.subscribeBtn} onPress={handleSubscribe}>
        <Text style={styles.subscribeText}>
          Subscribe • {selectedPlan === "annual" ? "R899.99" : "R89.99"}
        </Text>
        <Text style={styles.secure}>Secure payment via Stripe • Cancel anytime</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 60,
    paddingHorizontal: 20,
    backgroundColor: "#f9f9f9",
    alignItems: "center",
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1a73e8",
    marginBottom: 6,
  },
  subHeader: {
    fontSize: 14,
    color: "#555",
    textAlign: "center",
    marginBottom: 20,
  },
  planContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 20,
  },
  plan: {
    width: 140,
    padding: 15,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#ccc",
    marginHorizontal: 5,
    alignItems: "center",
    backgroundColor: "#fff",
  },
  activePlan: {
    borderColor: "#1a73e8",
    backgroundColor: "#eaf3ff",
  },
  planTitle: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 6,
    color: "#333",
  },
  planPrice: {
    fontSize: 14,
    color: "#1a73e8",
  },
  save: {
    fontSize: 12,
    color: "#28a745",
    marginBottom: 4,
  },
  features: {
    alignSelf: "stretch",
    marginVertical: 20,
  },
  feature: {
    fontSize: 14,
    marginBottom: 6,
    color: "#333",
  },
  footer: {
    fontSize: 12,
    color: "#777",
    marginTop: 4,
  },
  subscribeBtn: {
    marginTop: 20,
    backgroundColor: "#1a73e8",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
    width: "100%",
  },
  subscribeText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  secure: {
    fontSize: 12,
    color: "#fff",
    marginTop: 4,
  },
});
