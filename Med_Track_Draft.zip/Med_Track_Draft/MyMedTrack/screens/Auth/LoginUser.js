import React, { useState } from "react";
import "./Login.css";

export default function PatientLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSignIn = () => {
    alert(`Patient login with email: ${email}`);
  };

  return (
    <div className="login-container">
      <div className="logo">
        <div className="shield">🛡️</div>
        <h2>MedTrack</h2>
        <p className="tagline">Your health, always on schedule.</p>
      </div>

      <h3 className="role-title">Patient Login</h3>

      <form className="login-form" onSubmit={(e) => e.preventDefault()}>
        <label>EMAIL</label>
        <input
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <label>PASSWORD</label>
        <input
          type="password"
          placeholder="Enter your password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <div className="forgot" onClick={() => alert("Patient password recovery")}>
          Forgot password?
        </div>

        <button className="signin-btn" onClick={handleSignIn}>
          Sign In
        </button>

        <div className="biometric" onClick={() => alert("Patient biometric login")}>
          <span role="img" aria-label="fingerprint">🔑</span> Use Biometric / PIN
        </div>
      </form>

      <div className="footer">
        <p>
          New to MedTrack?{" "}
          <span className="create" onClick={() => alert("Patient account creation")}>
            Create account
          </span>
        </p>
        <small>HIPAA-compliant · End-to-end encrypted</small>
      </div>
    </div>
  );
}
