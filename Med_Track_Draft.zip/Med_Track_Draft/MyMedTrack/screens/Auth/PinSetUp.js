import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons"; // for backspace icon

export default function PinSetup() {
  const [pin, setPin] = useState("");

  const handlePress = (digit) => {
    if (pin.length < 6) {
      setPin(pin + digit);
    }
  };

  const handleDelete = () => {
    setPin(pin.slice(0, -1));
  };

  const handleBiometric = () => {
    alert("Biometric authentication triggered!");
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <Ionicons name="finger-print" size={40} color="#1a73e8" />
      <Text style={styles.title}>Set Your PIN</Text>
      <Text style={styles.subtitle}>
        Choose a 6-digit PIN to unlock MedTrack offline — even without internet.
      </Text>

      {/* PIN Circles */}
      <View style={styles.pinRow}>
        {[...Array(6)].map((_, i) => (
          <View
            key={i}
            style={[
              styles.circle,
              { backgroundColor: i < pin.length ? "#1a73e8" : "#fff" },
            ]}
          />
        ))}
      </View>

      {/* Keypad */}
      <View style={styles.keypad}>
        {["1","2","3","4","5","6","7","8","9","0"].map((digit, i) => (
          <TouchableOpacity
            key={i}
            style={styles.key}
            onPress={() => handlePress(digit)}
          >
            <Text style={styles.keyText}>{digit}</Text>
          </TouchableOpacity>
        ))}

        {/* Backspace */}
        <TouchableOpacity style={styles.key} onPress={handleDelete}>
          <Ionicons name="backspace-outline" size={24} color="#1a73e8" />
        </TouchableOpacity>
      </View>

      {/* Biometric Option */}
      <TouchableOpacity style={styles.biometric} onPress={handleBiometric}>
        <Ionicons name="finger-print" size={20} color="#1a73e8" />
        <Text style={styles.biometricText}> Use Face ID / Fingerprint instead</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 60,
    alignItems: "center",
    backgroundColor: "#f9f9f9",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginTop: 10,
    color: "#1a73e8",
  },
  subtitle: {
    fontSize: 14,
    textAlign: "center",
    marginVertical: 10,
    paddingHorizontal: 20,
    color: "#555",
  },
  pinRow: {
    flexDirection: "row",
    marginVertical: 20,
  },
  circle: {
    width: 18,
    height: 18,
    borderRadius: 9,
    borderWidth: 1,
    borderColor: "#1a73e8",
    marginHorizontal: 6,
  },
  keypad: {
    flexDirection: "row",
    flexWrap: "wrap",
    width: 240,
    justifyContent: "center",
    marginTop: 20,
  },
  key: {
    width: 70,
    height: 70,
    margin: 5,
    borderRadius: 35,
    backgroundColor: "#fff",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ccc",
  },
  keyText: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#333",
  },
  biometric: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 30,
  },
  biometricText: {
    fontSize: 14,
    color: "#1a73e8",
    marginLeft: 6,
  },
});
